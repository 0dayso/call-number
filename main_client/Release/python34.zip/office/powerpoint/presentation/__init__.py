class Presentation(object):
    from .slide import Slide
    def __init__(self,raw_pre,ppt):
        self._ppt=ppt
        self._raw=raw_pre
    def __del__(self):
        pass
    @property
    def raw(self):
        return self._raw

    def run(self):
        self.raw.SlideShowSettings.Run()

    def new(self,idx=1):
        raw_sli=self.raw.Slides.Add(idx,12)#12 means blank slide.
        return self.Slide(raw_sli,self)

    @property
    def slides(self):
        return [self.Slide(x,self) for x in self.raw.Slides]

    @property
    def width(self):
        return self.raw.PageSetup.SlideWidth
    @width.setter
    def width(self,w):
        self.raw.PageSetup.SlideWidth=w
        
    @property
    def height(self):
        return self.raw.PageSetup.SlideHeight
    @height.setter
    def height(self,h):
        self.raw.PageSetup.SlideHeight=h
