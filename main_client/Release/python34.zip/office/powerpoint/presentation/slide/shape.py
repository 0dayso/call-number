class Shape(object):
    """docstring for Slide."""
    def __init__(self, raw_sp,sli):
        self._slide=sli
        self._raw=raw_sp
    def __del__(self):
        pass
    @property
    def raw(self):
        return self._raw
    @property
    def font(self):
        return self.raw.TextFrame.TextRange.Font
    @property
    def text(self):
        return self.raw.TextFrame.TextRange.Text
    @text.setter
    def text(self,txt):
        self.raw.TextFrame.TextRange.Text=txt
