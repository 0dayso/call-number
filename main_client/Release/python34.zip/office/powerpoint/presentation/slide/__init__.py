class Slide(object):
    """docstring for Slide."""
    from .shape import Shape
    def __init__(self, raw_sld,pre):
        self._raw=raw_sld
        self._pre=pre
    def __del__(self):
        pass
    @property
    def raw(self):
        return self._raw

    @property
    def shapes(self):
        return [self.Shape(x,self) for x in self.raw.Shapes]
