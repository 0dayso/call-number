class Cell(object):
    """docstring for Cell"""
    def __init__(self, _cel):
        self._raw = _cel
    @property
    def raw(self):
        return self._raw
    @property
    def text(self):
        return self._raw.Range.Text
    @text.setter
    def text(self,txt):
        self._raw.Range.Text=txt
    def add_picture(self,pic_fn):
        pic=self._raw.Range.InlineShapes.AddPicture(pic_fn)
        sp=pic.ConvertToShape()
        sp.Top=0
        sp.Left=0
        sp.Width=self._raw.Width-1
        return sp
        #sp.Height=self._raw.Height-1
