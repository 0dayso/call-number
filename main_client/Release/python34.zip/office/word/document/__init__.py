class Document(object):
    """docstring for Doc"""
    from .shape import Shape
    from .table import Table
    def __init__(self, raw_doc,wd_app):
        self._raw=raw_doc
        self._app=wd_app

    def __del__(self):
        pass

    def __repr__(self):
        return 'Word.Document<%s>'%(self.name)

    @property
    def raw(self):
        return self._raw

    def replace(self,s_old,s_new,use_regex=True):
        if use_regex:
            import re
            spans=list(re.finditer(s_old,self.text))
            for x in spans[::-1]:
                rgn=self.raw.Range(*x.span())
                rgn.Text=re.sub(s_old,s_new,rgn.Text)
        else:
            self.raw.Select()
            find = self._app.raw.Selection.Find
            find.ClearFormatting()
            find.Execute(s_old,False, False, False, False, False, True, 1,True, s_new, 2)

    def replace_font(self,s,fun):
            import re
            for x in re.finditer(s,self.text):
                a,b=x.span()
                if a==b:
                    continue
                rgn=self.raw.Range(a,b)
                fun(rgn.Font)

    @property
    def name(self):
        return self.raw.Name

    @property
    def text(self):
        return self._raw.Content.Text
    @text.setter
    def text(self,txt):
        self._raw.Content.Text=txt

    @property
    def shapes(self):
        return list(map(self.Shape,self._raw.Shapes))

    @property
    def tables(self):
        return [self.Table(x) for x in self._raw.Tables]

    def saveas(self,fn):
        self._raw.SaveAs(fn)

    @property
    def raw(self):
        return self._raw

    def close(self):
        self._raw.Close(0)
