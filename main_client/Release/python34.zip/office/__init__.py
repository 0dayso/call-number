from .excel import Excel
from .powerpoint import PowerPoint
from .word import Word
